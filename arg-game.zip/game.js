// ============================================================
//  ARG GAME: "第47号广告" (The Ad That Shouldn't Exist)
//  借鉴《我的秘密花园》+《诡异广告调查事件》
// ============================================================

// ========== 全局状态 ==========
const STATE = {
    adClicks: 0,          // 广告被点击次数
    adClosed: false,       // 是否尝试关闭过广告
    adAngry: false,        // 广告是否进入愤怒状态
    foundClues: [],        // 已发现的线索
    cmdUnlocked: false,    // 命令提示符是否解锁
    glitchLevel: 0,        // 画面异常等级 0-5
    startTime: Date.now(),
    photoClicked: false,
    notepadText: '',
    terminalUnlocked: false,
};

// ========== 时钟 ==========
function updateClock() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2,'0');
    const m = String(now.getMinutes()).padStart(2,'0');
    const s = String(now.getSeconds()).padStart(2,'0');
    const el = document.getElementById('taskbar-clock');
    if(el) el.textContent = `${h}:${m}:${s}`;
}
setInterval(updateClock, 1000);
updateClock();

// ========== 窗口管理 ==========
function openWindow(id) {
    const win = document.getElementById('win-' + id);
    if(win) {
        win.style.display = 'block';
        // 提升z-index
        const all = document.querySelectorAll('.window');
        let maxZ = 100;
        all.forEach(w => { maxZ = Math.max(maxZ, parseInt(w.style.zIndex)||100); });
        win.style.zIndex = maxZ + 1;
    }
    if(id === 'cmd') {
        setTimeout(() => document.getElementById('cmd-input')?.focus(), 100);
    }
    if(id === 'photo') {
        if(STATE.glitchLevel >= 2) {
            document.getElementById('photo-hidden').style.display = 'block';
        }
    }
}
function closeWindow(id) {
    const win = document.getElementById('win-' + id);
    if(win) win.style.display = 'none';
}
function toggleStartMenu() {
    const m = document.getElementById('start-menu');
    m.style.display = m.style.display === 'none' ? 'block' : 'none';
}
document.addEventListener('click', (e) => {
    if(!e.target.closest('.start-btn') && !e.target.closest('.start-menu')) {
        document.getElementById('start-menu').style.display = 'none';
    }
});

// ========== 窗口拖拽 ==========
document.querySelectorAll('.window').forEach(win => {
    const title = win.querySelector('.window-title');
    if(!title) return;
    let dragging = false, offsetX, offsetY;
    title.addEventListener('mousedown', (e) => {
        dragging = true;
        offsetX = e.clientX - win.offsetLeft;
        offsetY = e.clientY - win.offsetTop;
    });
    document.addEventListener('mousemove', (e) => {
        if(dragging) {
            win.style.left = (e.clientX - offsetX) + 'px';
            win.style.top = (e.clientY - offsetY) + 'px';
        }
    });
    document.addEventListener('mouseup', () => { dragging = false; });
});

// ========== 广告逻辑 ==========
const adPopup = document.getElementById('ad-popup');
const adSold = document.getElementById('ad-sold');

function adClicked(action) {
    STATE.adClicks++;

    if(action === 'close') {
        STATE.adClosed = true;
        if(STATE.adClicks < 3) {
            // 前几次关不掉
            shakeAd();
            setTimeout(() => {
                addFoundClue('广告无法关闭');
                // 显示隐藏文字
                const bodies = document.querySelectorAll('.ad-body');
                if(bodies.length) {
                    const hint = document.createElement('div');
                    hint.style.cssText = 'font-size:9px;color:#ff0000;margin-top:4px;';
                    hint.textContent = '你注意到了吗？';
                    bodies[0].appendChild(hint);
                }
            }, 500);
            return;
        } else {
            // 第3次终于关掉了，但留下痕迹
            adPopup.style.display = 'none';
            addFoundClue('广告消失后桌面出现了异常文件');
            triggerGlitch(1);
            // 在桌面创建一个诡异文件
            createCreepyFile();
            return;
        }
    }

    if(action === 'later') {
        if(!STATE.adAngry) {
            STATE.adAngry = true;
            adPopup.classList.add('angry');
            const headline = document.querySelector('.ad-headline');
            if(headline) headline.innerHTML = '你确定吗？<br><span style="font-size:11px;color:#ff6666;">你真的确定？</span>';
            addFoundClue('广告开始变得有攻击性');
            triggerGlitch(1);
        } else {
            // 第二次点"以后再说" → 强制进入
            enterAdLanding();
        }
        return;
    }

    if(action === 'buy') {
        enterAdLanding();
        return;
    }

    if(action === 'body') {
        // 点击广告主体
        if(STATE.adClicks >= 5) {
            enterAdLanding();
        } else {
            // 随机变换广告内容
            const variants = [
                '失眠？焦虑？<br>记忆模糊？',
                '你还在看吗？<br>为什么还在看？',
                '第47号实验体<br>你在哪里？',
                'SOMNIA-47<br>我们一直在等你',
            ];
            const headline = document.querySelector('.ad-headline');
            if(headline) headline.innerHTML = variants[STATE.adClicks % variants.length];
        }
    }
}

function shakeAd() {
    adPopup.style.animation = 'none';
    adPopup.offsetHeight; // reflow
    adPopup.style.animation = 'adShake 0.3s 3';
    setTimeout(() => {
        adPopup.style.animation = '';
    }, 1000);
}

function createCreepyFile() {
    const desktop = document.querySelector('.desktop');
    const icon = document.createElement('div');
    icon.className = 'desktop-icon';
    icon.style.left = '20px';
    icon.style.top = '380px';
    icon.id = 'creepy-file';
    icon.innerHTML = `
        <div class="icon-img">⚠️</div>
        <div class="icon-label" style="color:#ff4444;">AD-0047.txt</div>
    `;
    icon.onclick = () => openCreepyFile();
    desktop.appendChild(icon);
}

function openCreepyFile() {
    // 创建新窗口显示诡异内容
    const existing = document.getElementById('win-creepy');
    if(existing) { existing.style.display='block'; return; }

    const win = document.createElement('div');
    win.className = 'window';
    win.id = 'win-creepy';
    win.style.cssText = 'left:180px;top:140px;width:380px;';
    win.innerHTML = `
        <div class="window-title"><span>AD-0047.txt</span><span class="close-btn" onclick="closeWindow('creepy')">×</span></div>
        <div class="window-body" style="font-family:monospace;font-size:12px;line-height:1.8;color:#333;background:#fff8f0;">
            <p style="color:#999;font-size:11px;">[文件恢复于 2007-03-14 23:47]</p>
            <br>
            <p>实验编号：0047</p>
            <p>药物名称：SOMNIA-47</p>
            <p>状态：<span style="color:red;">已终止</span></p>
            <br>
            <p>受试者报告：</p>
            <p style="padding-left:20px;">"我梦到了一个网站...</p>
            <p style="padding-left:20px;">...它在梦里面也是打不开的...</p>
            <p style="padding-left:20px;">...但是今天它自己打开了..."</p>
            <br>
            <p style="color:#666;font-size:11px;">[文件末尾有加密数据]</p>
            <p style="color:#ccc;font-size:10px;letter-spacing:1px;" id="encrypted-data">
                U2FsdGVkX1+2bW9ubm93cgo=
            </p>
            <br>
            <p style="font-size:11px;color:#888;">提示：试着把这句话解码 → "die vier sieben"</p>
        </div>
    `;
    document.body.appendChild(win);
    addFoundClue('发现了AD-0047的实验记录文件');
    triggerGlitch(2);
}

// ========== 进入广告落地页 ==========
function enterAdLanding() {
    // 保存当前状态到sessionStorage
    sessionStorage.setItem('arg_state', JSON.stringify(STATE));
    // 跳转
    window.location.href = 'landing.html';
}

// ========== 线索系统 ==========
function addFoundClue(text) {
    if(!STATE.foundClues.includes(text)) {
        STATE.foundClues.push(text);
        console.log(`[线索 ${STATE.foundClues.length}] ${text}`);
        // 在桌面右下角显示通知
        showNotification('新线索发现', text);
    }
}

function showNotification(title, text) {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position:fixed;bottom:40px;right:20px;width:260px;
        background:#245edc;color:#fff;padding:10px 14px;
        font-size:12px;border:1px solid #4a8af0;z-index:99998;
        box-shadow:2px 2px 8px rgba(0,0,0,0.4);
        animation:slideIn 0.3s ease;
    `;
    notif.innerHTML = `<b>${title}</b><br><span style="font-size:11px;color:#ccc;">${text}</span>`;
    document.body.appendChild(notif);
    setTimeout(() => {
        notif.style.transition = 'opacity 0.5s';
        notif.style.opacity = '0';
        setTimeout(() => notif.remove(), 500);
    }, 4000);
}

// ========== 画面异常 ==========
function triggerGlitch(level) {
    STATE.glitchLevel = Math.min(5, STATE.glitchLevel + level);
    const body = document.body;

    if(STATE.glitchLevel >= 1) {
        // 偶尔闪烁
        setInterval(() => {
            if(Math.random() < 0.05 * STATE.glitchLevel) {
                body.style.filter = `invert(${Math.random()*0.3}) hue-rotate(${Math.random()*90}deg)`;
                setTimeout(() => body.style.filter = '', 50);
            }
        }, 2000);
    }
    if(STATE.glitchLevel >= 3) {
        body.classList.add('glitch');
        setTimeout(() => body.classList.remove('glitch'), 3000);
    }
    if(STATE.glitchLevel >= 5) {
        // 终极异常：全屏闪红
        const flash = document.createElement('div');
        flash.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,0,0,0.15);z-index:999997;pointer-events:none;';
        document.body.appendChild(flash);
        setTimeout(() => flash.remove(), 200);
    }
}

// ========== 命令提示符 ==========
const CMD_HISTORY = [];
let cmdHistoryIdx = -1;

function handleCmd(e) {
    if(e.key === 'Enter') {
        const input = document.getElementById('cmd-input');
        const val = input.value.trim();
        input.value = '';
        CMD_HISTORY.push(val);
        cmdHistoryIdx = CMD_HISTORY.length;

        const output = document.getElementById('cmd-output');
        output.innerHTML += `<br>C:\\&gt; ${val}`;

        processCmd(val, output);
    } else if(e.key === 'ArrowUp') {
        if(cmdHistoryIdx > 0) {
            cmdHistoryIdx--;
            document.getElementById('cmd-input').value = CMD_HISTORY[cmdHistoryIdx];
        }
        e.preventDefault();
    } else if(e.key === 'ArrowDown') {
        if(cmdHistoryIdx < CMD_HISTORY.length - 1) {
            cmdHistoryIdx++;
            document.getElementById('cmd-input').value = CMD_HISTORY[cmdHistoryIdx];
        }
        e.preventDefault();
    }
}

function processCmd(cmd, output) {
    const c = cmd.toLowerCase();

    if(c === 'help') {
        output.innerHTML += `<br>可用命令:<br>help - 显示帮助<br>dir - 列出文件<br>type [文件] - 查看文件<br>cls - 清屏<br>whoami - 你是谁<br>netstat - 网络连接<br>findstr "47" - 搜索<br>exit - 关闭`;
    } else if(c === 'dir') {
        output.innerHTML += `<br> 驱动器 C 中的卷没有标签。<br> 卷的序列号是 0047-DEAD<br><br> C:\\ 的目录<br><br>03/14/2007 10:23 &lt;DIR&gt; Documents and Settings<br>03/14/2007 10:23 &lt;DIR&gt; Program Files<br>03/14/2007 10:23 &lt;DIR&gt; WINDOWS<br>03/14/2007 23:47 2,048 AD-0047.txt<br>03/14/2007 23:47 512 README.txt<br> 1 个文件 2,560 字节`;
    } else if(c.startsWith('type ')) {
        const file = c.substring(5);
        if(file === 'ad-0047.txt' || file === 'ad0047.txt') {
            output.innerHTML += `<br><span style="color:#ff4444;">实验编号：0047</span><br>药物：SOMNIA-47<br>受试者：47人<br>死亡：46人<br>失踪：1人<br>最后记录："它在梦里也在看我"`;
        } else if(file === 'readme.txt') {
            output.innerHTML += `<br>系统正常。<br>一切正常。<br>没有什么异常。<br>不要查看其他文件。`;
        } else {
            output.innerHTML += `<br>系统找不到指定的文件。`;
        }
    } else if(c === 'cls') {
        output.innerHTML = `C:\\&gt; <span id="cmd-cursor">_</span>`;
    } else if(c === 'whoami') {
        output.innerHTML += `<br>COMPUTER\\User<br><span style="color:#ff4444;font-size:11px;">或者...是47号？</span>`;
    } else if(c === 'netstat') {
        output.innerHTML += `<br><br>活动连接<br><br>协议 本地地址 外部地址 状态<br>TCP 0.0.0.0:47 0.0.0.0:0 LISTENING<br>TCP 192.168.1.47:31337 somnia.void:443 ESTABLISHED<br>TCP 192.168.1.47:47 void.archive:80 TIME_WAIT<br><br><span style="color:#ff4444;font-size:11px;">[发现异常连接：somnia.void]</span>`;
        addFoundClue('netstat发现异常连接: somnia.void:443');
    } else if(c === 'findstr "47"') {
        output.innerHTML += `<br>搜索 "47"...<br>C:\\AD-0047.txt: 实验编号：0047<br>C:\\AD-0047.txt: 药物：SOMNIA-47<br>C:\\AD-0047.txt: 失踪：1人<br>C:\\WINDOWS\\system32\\drivers\\etc\\hosts: 127.0.0.1 somnia.void<br><br><span style="color:#ff4444;">[hosts文件被修改过]</span>`;
        addFoundClue('hosts文件中发现somnia.void指向127.0.0.1');
    } else if(c === 'exit') {
        closeWindow('cmd');
    } else if(c === '') {
        // do nothing
    } else {
        output.innerHTML += `<br>"${cmd}" 不是内部或外部命令，也不是可运行的程序。`;
    }

    // 自动滚动到底部
    const cmdBody = document.querySelector('.cmd-body');
    if(cmdBody) cmdBody.scrollTop = cmdBody.scrollHeight;
}

// ========== 照片点击 ==========
document.addEventListener('DOMContentLoaded', () => {
    const photoIcon = document.querySelector('.desktop-icon:nth-child(4)');
    if(photoIcon) {
        photoIcon.addEventListener('click', () => {
            STATE.photoClicked = true;
            setTimeout(() => {
                const img = document.querySelector('#win-photo .window-body div');
                if(img && STATE.glitchLevel >= 1) {
                    img.classList.add('photo-glitch');
                    img.textContent = '';
                    img.style.background = 'linear-gradient(135deg,#ff0000,#330000)';
                    img.innerHTML = '<span style="color:#fff;font-size:13px;text-align:center;display:block;padding-top:80px;">你在照片里<br>看到了自己<br>但你不记得<br>这张照片</span>';
                }
            }, 300);
        });
    }

    // 检查是否从落地页返回
    const saved = sessionStorage.getItem('arg_state');
    if(saved) {
        try {
            const s = JSON.parse(saved);
            Object.assign(STATE, s);
        } catch(e) {}
    }

    // 随机桌面异常
    setInterval(() => {
        if(Math.random() < 0.02 && STATE.glitchLevel >= 2) {
            const icons = document.querySelectorAll('.desktop-icon');
            icons.forEach(icon => {
                if(Math.random() < 0.3) {
                    icon.style.transform = `translate(${(Math.random()-0.5)*10}px, ${(Math.random()-0.5)*10}px)`;
                    setTimeout(() => icon.style.transform = '', 200);
                }
            });
        }
    }, 3000);

    // 启动音频（低频嗡嗡声）
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 47; // 47Hz - 不祥的低频
        gain.gain.value = 0.02; // 极微弱
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        // 保存引用
        window.__argAudio = { ctx: audioCtx, osc, gain };
    } catch(e) {
        // 浏览器可能阻止自动播放
    }
});

// ========== 键盘彩蛋 ==========
document.addEventListener('keydown', (e) => {
    // 按 4 7 解锁终端
    if(e.key === '4') {
        setTimeout(() => {
            const handler = (e2) => {
                if(e2.key === '7') {
                    STATE.terminalUnlocked = true;
                    addFoundClue('解锁了隐藏终端访问');
                    showNotification('终端解锁', '输入命令 "somnia" 查看');
                    document.removeEventListener('keydown', handler);
                }
            };
            document.addEventListener('keydown', handler);
            setTimeout(() => document.removeEventListener('keydown', handler), 3000);
        }, 100);
    }

    // Ctrl+Shift+T 打开隐藏终端
    if(e.ctrlKey && e.shiftKey && e.key === 'T') {
        openHiddenTerminal();
    }
});

function openHiddenTerminal() {
    const existing = document.getElementById('hidden-term');
    if(existing) { existing.style.display='flex'; return; }

    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.id = 'hidden-term';
    overlay.style.display = 'flex';
    overlay.innerHTML = `
        <div class="terminal" style="width:80%;height:80%;max-width:900px;">
            <div class="amber">SOMNIA RECOVERY TERMINAL v0.47</div>
            <br>
            <div class="dim">正在恢复会话...</div>
            <div class="dim">已连接：somnia.void:47</div>
            <div class="dim">加密通道：已建立</div>
            <br>
            <div>═════════════════════════════════════</div>
            <br>
            <div>患者编号：<span class="red">0047</span></div>
            <div>姓名：<span class="red">[已编辑]</span></div>
            <div>诊断：急性失眠症 → 实验性治疗</div>
            <div>药物：SOMNIA-47（成分：未知）</div>
            <div>副作用：记忆碎片化、现实感知扭曲、时空错位</div>
            <br>
            <div>═════════════════════════════════════</div>
            <br>
            <div>实验记录：</div>
            <div>第1天：患者报告睡眠质量改善</div>
            <div>第7天：患者声称"梦到了另一个世界"</div>
            <div>第23天：患者开始在现实中说梦话，语言无法识别</div>
            <div>第37天：患者声称"镜子里的我不是我"</div>
            <div class="red">第47天：患者消失。监控录像显示患者走向一面墙，</div>
            <div class="red">然后"穿过"了墙面。墙后没有房间。</div>
            <br>
            <div>═════════════════════════════════════</div>
            <br>
            <div class="amber">正在检索购买者名单...</div>
            <div>共47人。其中46人已确认死亡或失踪。</div>
            <div class="red">第47人：[你的用户名]</div>
            <br>
            <div class="amber">正在检索你的记录...</div>
            <div>你于 [今天] 点击了广告 AD-0047</div>
            <div class="red">你已自愿参与实验</div>
            <div class="red">实验编号：0047-REBOOT</div>
            <br>
            <div>═════════════════════════════════════</div>
            <br>
            <div class="red" style="animation:dotBlink 1s infinite;">连接中断...</div>
            <br><br>
            <div style="font-size:11px;color:#225522;">提示：在命令提示符中输入 "somnia" 可重新打开此终端</div>
            <div style="font-size:11px;color:#225522;">提示：在落地页找到3个"47"可解锁下一层</div>
            <div style="font-size:11px;color:#225522;">提示：留言板的密码是 23</div>
            <br><br>
            <button onclick="document.getElementById('hidden-term').style.display='none'" 
                style="background:#003300;color:#33ff33;border:1px solid #33ff33;padding:4px 12px;cursor:pointer;font-family:monospace;">
                [关闭终端]
            </button>
        </div>
    `;
    document.body.appendChild(overlay);
    triggerGlitch(3);
}
